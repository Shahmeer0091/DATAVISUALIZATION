"""
partC_shares.py -- Week 4, Part C: part-to-whole legality and the pie-ranking experiment.

    python3 partC_shares.py                 # C.1 tests + draws the two stimuli
    python3 partC_shares.py run  Name       # C.2 run the timed experiment on a REAL reader
    python3 partC_shares.py run  Name --first bars   # counterbalance the order
    python3 partC_shares.py score           # C.3 score pie_ranking_results.csv

Nothing here fabricates a result: pie_ranking_results.csv is written only by
`run`, from a person's typed answers and time.perf_counter().
"""
from pathlib import Path
import sys
import time
import csv

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tslib import PALETTE, style_defaults, save_fig, exclusivity_check
from clean_sessions import DATA

HERE = Path(__file__).parent
RESULTS = HERE / "pie_ranking_results.csv"
PIE_PNG, BAR_PNG = HERE / "partC_stimulus_pie.png", HERE / "partC_stimulus_bars.png"


def load_shares():
    sh = pd.read_csv(DATA / "shares_eight.csv")
    assert abs(sh.share_pct.sum() - 100) < 1e-6
    return sh


def true_order(sh):
    return "".join(sh.sort_values("share_pct", ascending=False).slice)


# ----------------------------------------------------------------- C.1
def legality():
    print("=== C.1  the three conditions (slide 32) ===\n")
    # --- table 1: touch_* columns
    d = pd.read_csv(DATA / "case08_channel_attrib.csv")
    r = exclusivity_check(d, [c for c in d if c.startswith("touch_")])
    print("1) touch_* columns of case08_channel_attrib.csv")
    print(f"   exclusive parts?  NO  - {r['n_multi']:,} of {r['n']:,} customers ({r['pct_multi']}%) "
          f"are in 2+ channels; shares sum to {r['sum_pct']}%")
    print("   meaningful whole? NO  - 'customers' is a whole, but the slices are overlapping "
          "sets, not a split of it")
    print("   share the question? NO - the question is reach per channel, which is a separate "
          "number for each")
    print("   VERDICT: neither pie nor stacked/treemap. Bar chart of per-channel reach "
          "(each bar its own %, from zero), not labelled as shares of a whole.\n")

    # --- table 2: shares_eight
    sh = load_shares()
    cat = pd.read_csv(DATA / "revenue_catalogue.csv")
    print("2) the eight rows of shares_eight.csv")
    print(f"   exclusive parts?  YES - each SKU sits under one sub-category "
          f"({cat.subcategory.nunique()} sub-categories in the catalogue, all eight present)")
    print(f"   meaningful whole? YES - total net revenue of the catalogue; shares sum to "
          f"{sh.share_pct.sum():.1f}%")
    print("   share the question? PARTLY - 'where is the mass' yes; 'which is bigger, C or H' "
          "is a ranking question (C 15.0, H 13.1, G 11.2 are 1.9 and 1.9 points apart)")
    print("   VERDICT: legal as a pie, but eight slices that must be RANKED belong in sorted "
          "bars (Part C.2 tests this). A treemap if the hierarchy matters.\n")

    # --- table 3: premium vs other, 2025Q4
    q = pd.read_csv(DATA / "case09_premium_share.csv").set_index("quarter").loc["2025Q4"]
    other = q.total_revenue_pkr_m - q.premium_revenue_pkr_m
    print("3) premium vs other revenue, 2025Q4 (case09_premium_share.csv)")
    print(f"   exclusive parts?  YES - premium is one line of total; other = total - premium "
          f"= {other:.0f}")
    print(f"   meaningful whole? YES - all revenue that quarter ({q.total_revenue_pkr_m:.0f} PKR m)")
    print(f"   share the question? ONLY for that one quarter ({q.premium_revenue_pkr_m / q.total_revenue_pkr_m * 100:.0f}% / "
          f"{other / q.total_revenue_pkr_m * 100:.0f}%). The real question is change over time, "
          "where a share hides that the whole shrank (Part A case 9)")
    print("   VERDICT: a two-slice pie is legal for 2025Q4 alone, but a bar of the two LEVELS "
          "(or the Part A case 9 line chart) answers the real question. Not a pie over time.\n")


# ----------------------------------------------------------------- stimuli
def draw_stimuli():
    style_defaults()
    sh = load_shares()
    # pie: file order, no numbers on it, letters only
    fig, ax = plt.subplots(figsize=(6.5, 6.5))
    cols = plt.get_cmap("tab10")(np.arange(8))
    ax.pie(sh.share_pct, labels=sh.slice, startangle=90, counterclock=False,
           colors=cols, wedgeprops=dict(edgecolor="white"), textprops=dict(fontsize=16))
    ax.grid(False)
    ax.set_title("Rank the slices A-H, largest first", fontsize=13)
    save_fig(fig, PIE_PNG)
    plt.close(fig)
    # sorted horizontal bars, no numbers either, so only the channel differs
    b = sh.sort_values("share_pct")
    fig, ax = plt.subplots(figsize=(6.5, 5))
    ax.barh(b.slice, b.share_pct, color=PALETTE["series"][0], height=0.65)
    ax.set_xlim(0, 28)
    ax.set_xlabel("Share of net revenue (%)")
    ax.set_title("Rank the bars A-H, largest first", fontsize=13)
    for sp in ax.spines.values():
        sp.set_visible(False)
    save_fig(fig, BAR_PNG)
    plt.close(fig)
    print(f"stimuli saved: {PIE_PNG.name}, {BAR_PNG.name}")


# ----------------------------------------------------------------- C.2
def run(reader, first="pie"):
    draw_stimuli()
    order = ["pie", "bars"] if first == "pie" else ["bars", "pie"]
    files = {"pie": PIE_PNG, "bars": BAR_PNG}
    rows = []
    print(f"\nReader: {reader}. Presentation order: {order}.")
    for stim in order:
        print(f"\nOpen {files[stim].name}. Press Enter to start the clock, then type the "
              f"letters A-H largest first (e.g. ABCDEFGH) and press Enter.")
        input()
        t0 = time.perf_counter()
        ans = input("order> ").strip().upper().replace(" ", "").replace(",", "")
        secs = round(time.perf_counter() - t0, 2)
        rows.append(dict(reader=reader, stimulus=stim, order=ans, seconds=secs,
                         presented=order.index(stim) + 1))
        print(f"recorded {ans} in {secs}s")
    new = not RESULTS.exists()
    with open(RESULTS, "a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["reader", "stimulus", "order", "seconds", "presented"])
        if new:
            w.writeheader()
        w.writerows(rows)
    print(f"\nappended to {RESULTS.name}. Now run: python3 partC_shares.py score")


# ----------------------------------------------------------------- C.3
def score():
    if not RESULTS.exists():
        sys.exit("pie_ranking_results.csv does not exist yet - run the experiment first "
                 "(python3 partC_shares.py run YourReader).")
    sh = load_shares()
    truth = true_order(sh)
    ranked = sh.sort_values("share_pct", ascending=False)
    print(f"true order (largest first): {truth}   "
          f"({', '.join(f'{r.slice} {r.share_pct}' for r in ranked.itertuples())})")
    res = pd.read_csv(RESULTS)
    for r in res.itertuples():
        ans = str(r.order)
        wrong = [i + 1 for i, (a, t) in enumerate(zip(ans, truth)) if a != t]
        print(f"\n{r.reader} / {r.stimulus}: answered {ans} in {r.seconds}s "
              f"(shown {r.presented}{'st' if r.presented == 1 else 'nd'})")
        print(f"  letters in the wrong rank: {len(wrong)} of 8; wrong at ranks {wrong}")
        top2 = ans[:2] == truth[:2]
        bottom = ans[-1:] == truth[-1:]
        mid = ans[2:5] == truth[2:5]
        print(f"  top two right: {top2}; bottom one right: {bottom}; "
              f"middle (C, H, G) right: {mid}")
    print("\nLimits: one reader is one reader. Times include reading, typing and "
          "the order shown first (practice/fatigue); this cannot establish an effect, "
          "only show whether it points the way the deck predicts.")


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        legality()
        draw_stimuli()
        print("\nTrue order:", true_order(load_shares()))
    elif a[0] == "run":
        run(a[1] if len(a) > 1 else "reader1", first=a[a.index("--first") + 1] if "--first" in a else "pie")
    elif a[0] == "score":
        score()
    else:
        sys.exit(__doc__)
