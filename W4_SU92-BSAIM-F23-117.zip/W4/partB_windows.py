"""
partB_windows.py -- Week 4, Part B: smoothing, windows and panel shape, computed.

Run:  python3 partB_windows.py            (prints to screen and to partB_output.txt)
Works on the cleaned daily session series from Part D (clean_sessions.py).

If statsmodels is installed it is used for seasonal_decompose; if not, an
equivalent classical additive decomposition (centred moving-average trend,
mean-by-position seasonal, residual = remainder) is used instead.
"""
from pathlib import Path
import warnings

import numpy as np
import pandas as pd

from clean_sessions import load_clean_sessions, DATA
from tslib import window_report, lag_at_turn, banked_figsize

warnings.filterwarnings("ignore")
HERE = Path(__file__).parent
OUT = []


def p(msg=""):
    print(msg)
    OUT.append(str(msg))


def classical_decompose(y: pd.Series, period: int):
    """Additive classical decomposition, as statsmodels does it."""
    if period % 2 == 0:
        w = np.r_[0.5, np.ones(period - 1), 0.5] / period
    else:
        w = np.ones(period) / period
    trend = pd.Series(np.convolve(y.to_numpy(), w, mode="valid"),
                      index=y.index[(len(w) - 1) // 2: len(y) - (len(w) - 1) // 2])
    trend = trend.reindex(y.index)
    detr = y - trend
    pos = np.arange(len(y)) % period
    seas = detr.groupby(pos).mean()
    seas = seas - seas.mean()
    seasonal = pd.Series(seas.reindex(pos).to_numpy(), index=y.index)
    return trend, seasonal, y - trend - seasonal


def decompose(y, period):
    try:
        from statsmodels.tsa.seasonal import seasonal_decompose
        r = seasonal_decompose(y, model="additive", period=period)
        return r.trend, r.seasonal, r.resid, "statsmodels"
    except ImportError:
        t, s, r = classical_decompose(y, period)
        return t, s, r, "built-in classical (statsmodels not installed)"
    except ValueError as e:      # e.g. fewer than two full cycles
        t, s, r = classical_decompose(y, period)
        return t, s, r, f"built-in classical (statsmodels refused: {e})"


def main():
    hourly, daily, slog = load_clean_sessions()
    s = daily["sessions"]
    p(f"series: {s.index.min().date()} to {s.index.max().date()}, {len(s)} days, "
      f"{int(s.isna().sum())} unrecorded (NaN)\n")

    # ================= B.1 window report ================================
    p("=== B.1  window_report (centred) ===")
    rep = window_report(s, windows=(7, 28, 91))
    rep["cycle_removed"] = ["weekly (7 d)", "weekly (4 whole weeks); any ~monthly cycle", "quarterly; also part of the seasonal arc"]
    p(rep.to_string(index=False))
    p("Chosen for Part D: 7 days. The cycle to cancel is the weekly one (weekend lift "
      "~36% over Mon-Thu). 28 and 91 remove more variation but they also erase the "
      "seasonal arc and the Black Friday event we want to see. Fixed BEFORE plotting.\n")

    # ================= B.2 three smoothers vs one spike =================
    p("=== B.2  Black Friday 2024-11-29 ===")
    bf = pd.Timestamp("2024-11-29")
    raw = s.loc[bf]
    fort = s.loc[bf - pd.Timedelta(days=7): bf + pd.Timedelta(days=6)]
    mean14 = s.rolling(14, center=True, min_periods=7).mean().loc[bf]
    med14 = s.rolling(14, center=True, min_periods=7).median().loc[bf]
    ewma = s.ewm(span=14, adjust=False, ignore_na=True).mean().loc[bf]
    p(f"raw value            : {raw:,.0f}")
    p(f"fortnight median     : {np.nanmedian(fort):,.0f}  (brief: ~24,600; differs slightly with the fortnight's exact start day)")
    p(f"14-day centred mean  : {mean14:,.0f}   (pulled up {mean14 - np.nanmedian(fort):,.0f} by one day)")
    p(f"14-day centred median: {med14:,.0f}   (barely moves)")
    p(f"EWMA span=14         : {ewma:,.0f}   (trailing by construction; spike decays slowly)")
    p("Monitoring dashboard : the MEDIAN - one bad collector hour must not drag the line.")
    p("Quarterly report     : the MEAN - the spike is real revenue-bearing traffic and "
      "belongs in the total; show it, and name the event.\n")

    # ================= B.3 decomposition ===============================
    p("=== B.3  seasonal_decompose (additive) ===")
    y = s.interpolate(limit_direction="both")      # decomposition needs a gapless series
    p(f"(the {int(s.isna().sum())} unrecorded days are linearly interpolated for this "
      f"step ONLY; the figures in Part D keep them as gaps)")
    t7, s7, r7, how7 = decompose(y, 7)
    amp = s7.iloc[:7].max() - s7.iloc[:7].min()
    big = r7.abs().idxmax()
    names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    sw = s7.groupby(s7.index.dayofweek).first()
    p(f"engine: {how7}")
    p(f"weekly seasonal component, peak-to-trough amplitude: {amp:,.0f} sessions/day "
      f"(peak {names[int(sw.idxmax())]} {sw.max():+,.0f}, trough {names[int(sw.idxmin())]} {sw.min():+,.0f})")
    p(f"largest residual: {big.date()}  = {r7.loc[big]:+,.0f} sessions")
    p(f"top-3 |residual| dates: {[str(d.date()) for d in r7.abs().nlargest(3).index]}")
    try:
        from statsmodels.tsa.seasonal import seasonal_decompose  # noqa
        have_sm = True
    except ImportError:
        have_sm = False
    p(f"period=365: {len(y)} days available; a decomposition needs two complete cycles "
      f"(730), so statsmodels would raise ValueError here" + ("" if have_sm else " (not installed in this run)"))
    t365, s365, r365, how365 = decompose(y, 365)
    p(f"  relaxed built-in run, for illustration only: seasonal range "
      f"{s365.max() - s365.min():,.0f}; trend defined for {int(t365.notna().sum())} days")
    p("  What moves: the yearly arc (rise to the November peak, fall in spring) leaves "
      "the trend/resid and is claimed by `seasonal`; the weekly cycle stays in resid.\n")

    # ================= B.4 trailing vs centred =========================
    p("=== B.4  lag_at_turn, 31-day window ===")
    c4 = pd.read_csv(DATA / "case04_intervention_lag.csv", parse_dates=["date"]) \
           .set_index("date").conversion_pct
    r = lag_at_turn(c4, 31, how="min")
    p(f"conversion series (the turn is a trough): trailing {r['trailing_turn'].date()}, "
      f"centred {r['centred_turn'].date()}, lag {r['lag_periods']} d vs half-window {r['half_window']} d")
    r2 = lag_at_turn(y, 31, how="max")
    p(f"sessions series (the turn is the peak of the smoothed series): trailing {r2['trailing_turn'].date()}, "
      f"centred {r2['centred_turn'].date()}, lag {r2['lag_periods']} d vs half-window {r2['half_window']} d")
    p("Lag = half the window (15 d for 31): a trailing mean cannot know about a turn until the "
      "window has filled with post-turn days.")
    p("A morning dashboard must show the TRAILING mean (tomorrow's data does not exist yet; a "
      "centred line would be silently re-drawn or end 15 days early). Caption: "
      "'31-day trailing mean; turning points appear about 15 days after they happen.'\n")

    # ================= B.5 the window is a claim =======================
    p("=== B.5  12 start months x 5 windows ===")
    starts = pd.date_range(s.index.min().replace(day=1), periods=12, freq="MS")
    rows = []
    end = s.index.max()
    for st in starts:
        for w in (7, 14, 28, 56, 91):
            sm = s.rolling(w, center=True, min_periods=max(2, w // 2)).mean().loc[st:end].dropna()
            x = np.arange(len(sm))
            slope = np.polyfit(x, sm.to_numpy(), 1)[0]
            rows.append((st.strftime("%Y-%m"), w, slope))
    g = pd.DataFrame(rows, columns=["start", "window", "slope"])
    rising, falling = int((g.slope > 0).sum()), int((g.slope < 0).sum())
    p(f"combinations: {len(g)}   RISING: {rising}   FALLING: {falling}")
    p(g.assign(trend=np.where(g.slope > 0, "rise", "fall")).pivot(index="start", columns="window",
                                                                   values="trend").to_string())
    p("falling starts: " + ", ".join(sorted(set(g.start[g.slope < 0]))) if falling else "no falling starts")
    p("Why the Lie Factor cannot be computed here: it is (effect shown) / (effect in the data), and "
      "it assumes ONE true effect exists in the data to divide by. A cherry-picked window has no "
      "single 'effect in the data' - the data hold every one of these slopes at once, so the "
      "denominator is undefined.")
    p("Honest substitute: report the SPREAD across defensible windows (here "
      f"{rising} rising / {falling} falling of {len(g)}), or publish the pre-declared window "
      "plus a sensitivity table, so the reader sees what the choice could have done.\n")

    # aspect ratio (Part B title: panel shape)
    w_in, h_in = banked_figsize(s.interpolate().rolling(7, center=True, min_periods=4).mean().dropna().to_numpy())
    p(f"banked-to-45 figsize for the 7-day mean: {w_in:.1f} x {h_in:.1f} in (aspect {h_in / w_in:.2f})")

    (HERE / "partB_output.txt").write_text("\n".join(OUT), encoding="utf-8")


if __name__ == "__main__":
    main()
