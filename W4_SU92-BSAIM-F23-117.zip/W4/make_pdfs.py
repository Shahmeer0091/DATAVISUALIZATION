"""
make_pdfs.py -- builds partA_diagnosis.pdf and partE_justification.pdf.
Every number is read from partA_numbers.json / partD_log.txt / partB_output.txt
(written by the scripts), not typed by hand where a script produced it.

Run order:  partA_charts.py, partB_windows.py, partD_figure.py, then this.
"""
from pathlib import Path
import json

from PIL import Image
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as RLImage, PageBreak

HERE = Path(__file__).parent
N = json.loads((HERE / "partA_numbers.json").read_text())


def styles(size=9.2, lead=12):
    return dict(
        h=ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=13, leading=16, spaceAfter=4),
        claim=ParagraphStyle("c", fontName="Helvetica-Oblique", fontSize=size, leading=lead,
                             textColor=colors.HexColor("#5B6573"), spaceAfter=4),
        b=ParagraphStyle("b", fontName="Helvetica", fontSize=size, leading=lead, spaceAfter=3.5),
        small=ParagraphStyle("s", fontName="Helvetica", fontSize=7.2, leading=9,
                             textColor=colors.HexColor("#5B6573")),
    )


def fig(path, width_cm=17.4):
    w, h = Image.open(path).size
    return RLImage(str(path), width=width_cm * cm, height=width_cm * cm * h / w)


def lab(t):
    return f"<b>{t}</b> "


# ------------------------------------------------------------------ Part A
def case_text():
    c1, c2, c3, c4, c5 = N["c1"], N["c2"], N["c3"], N["c4"], N["c5"]
    c6, c7, c8, c9 = N["c6"], N["c7"], N["c8"], N["c9"]
    return [
        ("1 · \"Orders peak in Q1 and collapse every year\"", "case01_orders_stringdate.csv", [
            ("Rebuilt.", "24 points; climbs 4 points, drops 958, climbs 11, drops 978, climbs again (asserted in code)."),
            ("Conclusion and decoy.", "The chart invites: an annual cycle that peaks in Q1 and collapses. First objection: "
             "\"real seasonality\". Ruled out: in true date order there are "
             f"<b>{c1['falling_months']} falling months out of 23</b>; orders rise every month, from {c1['start']:,} to {c1['end']:,}."),
            ("Mechanism.", "<b>month</b> is text, written YYYY-M with no zero padding, so it sorts as text: '2024-1' &lt; '2024-10' "
             "&lt; '2024-11' &lt; '2024-12' &lt; '2024-2'. Oct-Dec are placed before Feb-Sep, which fabricates the "
             f"two drops (958 and 978). Parsed and sorted correctly the series climbs +{c1['growth_pct']}% (about +{c1['mean_step']:.0f} orders a month) with no cycle at all."),
            ("Redesign.", "Right panel: dates parsed with pd.to_datetime, then sorted; one monotone line."),
        ]),
        ("2 · \"Sales grew steadily, 22%, across the quarter\"", "case02_shop_closed.csv", [
            ("Rebuilt.", "69 points, first 207, last 253, +22.2%; trend fitted against row number."),
            ("Conclusion and decoy.", "Invites: steady growth. Objection: \"the dates are just labels, closed days do not matter\". "
             f"They do: only {c2['rows']} of {c2['calendar_days']} calendar days are recorded; {c2['closed_days']} are missing, "
             f"almost all of them one {c2['gap_days']}-day closure ({c2['gap_from']} to {c2['gap_to']})."),
            ("Mechanism.", "A step, not a trend. Mean before the closure "
             f"<b>{c2['pre_mean']}</b>, after <b>{c2['post_mean']}</b> (<b>+{c2['step_pct']}%</b>); sales went {c2['sales_before_gap']} to "
             f"{c2['sales_after_gap']} across the gap. Inside each block the slope is flat "
             f"({c2['slope_pre']:+.2f} and {c2['slope_post']:+.2f} per day). Plotting against row number deletes the 21 days and turns "
             f"the step into a slope ({c2['slope_per_row']:.2f} per row vs {c2['slope_per_day']:.2f} per calendar day)."),
            ("Redesign.", "Same series on a calendar axis, closure left as a visible gap, segment means drawn. "
             "The chart was incomplete rather than arithmetically wrong."),
        ]),
        ("3 · \"Peak load jumped 43% overnight on 1 July\"", "case03_bandwidth_levels.csv", [
            ("Rebuilt.", f"Daily .sum() of concurrent_users: June mean {c3['jun_daily_sum']:,}, July {c3['jul_daily_sum']:,}, +{c3['step_pct']}%."),
            ("Conclusion and decoy.", "Invites: a launch-day step in load. Objection: \"July really is busier\". Ruled out with the data: "
             f"mean users per recorded hour went {c3['jun_hour_mean']} to {c3['jul_hour_mean']} (<b>{c3['hour_mean_change_pct']:+}%</b>) "
             f"and the mean daily peak hour {c3['jun_peak_mean']} to {c3['jul_peak_mean']}."),
            ("Mechanism.", "concurrent_users is a <b>level</b> (users connected at an instant), and a level must not be summed. A sum counts "
             f"how many hours were recorded: June has {c3['jun_hours']} of 720 hours ({c3['jun_hours_per_day']} per day), "
             f"July {c3['jul_hours']} of 744 (24 per day, complete from 1 July). {c3['missing_hours']} hours are missing, all in June. "
             f"Ratio 24 / {c3['jun_hours_per_day']} = 1.46, which is the 43% step."),
            ("Redesign.", "Daily mean and daily peak (aggregations that suit a level) with a coverage strip beneath showing hours recorded per day."),
        ]),
        ("4 · \"The new checkout flow started working on 7 September\"", "case04_intervention_lag.csv", [
            ("Rebuilt.", "Raw grey, 31-day trailing mean; the trailing mean bottoms out on 2025-09-07 (asserted)."),
            ("Conclusion and decoy.", "Invites: the improvement began 7 Sep. Objection: \"the smoothed line is just a cleaner view of the raw one\". "
             f"Not at the turning point: the raw series 7-day centred mean bottoms on {c4['c7_min']}, the 31-day centred mean on <b>{c4['centred_min']}</b>."),
            ("Mechanism.", f"A trailing window can only see a turn once it has filled. Trailing minimum {c4['trailing_min']} minus centred minimum "
             f"{c4['centred_min']} = <b>{c4['lag_days']} days = half the 31-day window</b>. The date read off the smoothed line "
             "is the date the window caught up, not the date the behaviour changed. (The data also cannot say when the flow shipped.)"),
            ("Redesign.", "Same chart with the centred 31-day mean overlaid and both dates marked; the lag is labelled on the figure."),
        ]),
        ("5 · \"Revenue has fallen for six straight months\"", "case05_revenue_window.csv", [
            ("Rebuilt.", "7 points, 158.8 down to 92.2, -41.9%, y-axis from zero."),
            ("Conclusion and decoy.", "Invites: a business in decline. Both obvious objections fail: the axis is from zero (not truncated), "
             f"and n = {c5['n']} is a window, not the sample: the file holds 36 months."),
            ("Mechanism.", "The window starts at the seasonal peak and ends at the seasonal trough. The same May-to-November fall happens every year: "
             f"2023 {c5['same_window_2023_fall_pct']}%, 2024 {c5['same_window_2024_fall_pct']}%, 2025 {c5['fall_pct']}%. "
             f"Year on year the business grew: May {c5['yoy_may']:+}%, November {c5['yoy_nov']:+}%; annual totals "
             f"{c5['annual_total']['2023']:,.0f}, {c5['annual_total']['2024']:,.0f}, {c5['annual_total']['2025']:,.0f} PKR m."),
            ("Redesign.", "Cycle plot, one line per year, published window shaded. Incomplete rather than wrong: the numbers are right, the frame is a half-cycle."),
        ]),
        ("6 · \"Orders collapsed in October\"", "case06_monthly_partial.csv", [
            ("Rebuilt.", f"Monthly .sum(), ten bars, September {c6['sep_total']:,}, October {c6['oct_total']:,} ({c6['oct_pct_of_sep']}%)."),
            ("Conclusion and decoy.", "Invites: demand collapsed. Objection: \"maybe it did, the data are what they are\". "
             f"Check the calendar: the file ends on <b>{c6['last_day']}</b>, so October has {c6['oct_days']} of 31 days."),
            ("Mechanism.", f"An incomplete period summed against complete ones. Orders per day: September {c6['sep_rate']}, October {c6['oct_rate']} "
             f"(<b>{c6['rate_change_pct']:+}%</b>). At September's rate a full October would be about {c6['expected_oct_total_at_sep_rate']:,}."),
            ("Redesign.", "Orders per recorded day, with October hatched and labelled \"11 of 31 days\". Incomplete rather than wrong."),
        ]),
        ("7 · \"Product D has been erratic since mid-2024\"", "case07_stacked_products.csv", [
            ("Rebuilt.", f"Stacked area A (bottom) to D (top); total envelope {c7['total_min']} to {c7['total_max']}."),
            ("Conclusion and decoy.", "Invites: D became volatile. Objection: \"D is genuinely noisy\". Measured: D's month-to-month SD is "
             f"<b>{c7['sd_step']['product_d']}</b> (range {c7['d_min']}-{c7['d_max']}); since July 2024 it is {c7['d_sd_step_since_2024_07']}."),
            ("Mechanism.", "The column the recipe never isolates is <b>product_b</b>: month-to-month SD "
             f"{c7['sd_step']['product_b']} ({c7['ratio_b_over_d']}x D's), range {c7['b_min']}-{c7['b_max']}, erratic from 2023. In a stack only the bottom "
             "layer has a flat baseline; every layer above inherits the wiggle of all below it, so D's outline carries B's swings."),
            ("Redesign.", "Unstacked small multiples on one shared y-axis from zero (Week 1's two ways out of spaghetti: unstack or facet)."),
        ]),
        ("8 · \"Paid search drives 43% of our customers\"", "case08_channel_attrib.csv", [
            ("Rebuilt.", "Search 42.6%, social 32.3%, email 27.5%, direct 28.6% drawn as a four-slice pie."),
            ("Conclusion and decoy.", "Invites: search is 43% of the pie. Objection: \"just rescale the slices to 100%\". That gives search "
             f"{c8['search_normalised_pct']}%, a number that measures nothing in the data."),
            ("Mechanism.", f"The four slices sum to <b>{c8['sum_pct']}%</b>. The parts are not exclusive: {c8['n_multi']:,} of {c8['n']:,} customers "
             f"({c8['pct_multi']}%) were touched by two or more channels (2: {c8['touches_hist']['2']}, 3: {c8['touches_hist']['3']}, 4: {c8['touches_hist']['4']}). "
             f"Only {c8['sole_touch_pct']['search']}% were touched by search alone. \"Touched\" is reach; \"drives\" is attribution, which these columns cannot give."),
            ("Redesign.", "Per-channel reach as bars from zero, with the touched-only-by-this-channel part overlaid; no pie."),
        ]),
        ("9 · \"Premium is now 38% of revenue, a record\"", "case09_premium_share.csv", [
            ("Rebuilt.", "Share rises 24.0% to 38.0%, y-axis from zero, last point annotated."),
            ("Conclusion and decoy.", "Invites: premium is growing fast. Objection: \"the ratio is miscomputed or the axis exaggerates\". Neither: "
             "the arithmetic and baseline are right, and 38.0% is a record share."),
            ("Mechanism.", f"The denominator is collapsing. Total {c9['total_first']:,.0f} to {c9['total_last']:,.0f} PKR m (<b>{c9['total_change_pct']}%</b>); "
             f"premium {c9['premium_first']:.0f} to {c9['premium_last']:.0f} (<b>{c9['premium_change_pct']}%</b>, peak was {c9['premium_peak_q']}); "
             f"the rest {c9['other_first']:.0f} to {c9['other_last']:.0f} ({c9['other_change_pct']}%). Had premium stayed at 240 the share would be {c9['share_if_premium_flat_at_first']}%."),
            ("Redesign.", "The same story with the levels beside it: premium flat-to-down, everything else halving. Incomplete rather than wrong."),
        ]),
    ]


def build_A():
    st = styles()
    doc = SimpleDocTemplate(str(HERE / "partA_diagnosis.pdf"), pagesize=A4,
                            leftMargin=1.7 * cm, rightMargin=1.7 * cm, topMargin=1.4 * cm, bottomMargin=1.2 * cm,
                            title="Week 4 Part A: diagnosis of nine charts")
    story = [Paragraph("Week 4 · Part A: nine charts, rebuilt and taken apart", st["h"]),
             Paragraph("Each page: the published chart (left) and the redesign (right), then conclusion + decoy, mechanism with the number "
                       "that shows it, and the redesign. All data are synthetic course data (CDB601220). Every number below is produced by "
                       "partA_charts.py (partA_numbers.json).", st["claim"]), Spacer(1, 0.3 * cm)]
    for i, (title, f, items) in enumerate(case_text(), start=1):
        if i > 1:
            story.append(PageBreak())
        story += [Paragraph(title, st["h"]), Paragraph(f"data: {f}", st["claim"]),
                  fig(HERE / f"partA_case{i:02d}.png"), Spacer(1, 0.25 * cm)]
        for k, t in items:
            story.append(Paragraph(lab(k) + t, st["b"]))
    doc.build(story)


# ------------------------------------------------------------------ Part E
def build_E():
    st = styles(size=8.5, lead=10.8)
    st["h"].fontSize = 11.5
    st["h"].leading = 13
    st["sec"] = ParagraphStyle("sec", fontName="Helvetica-Bold", fontSize=8.2, leading=10, spaceBefore=3.5,
                               spaceAfter=1.2, textColor=colors.HexColor("#0072B2"))
    doc = SimpleDocTemplate(str(HERE / "partE_justification.pdf"), pagesize=A4,
                            leftMargin=1.4 * cm, rightMargin=1.4 * cm, topMargin=1.1 * cm, bottomMargin=0.9 * cm,
                            title="Week 4 Part E: justification")
    s = []
    P = lambda t, k="b": s.append(Paragraph(t, st[k]))
    P("Week 4 · Part E: justification for the e-commerce Monday-review figure", "h")
    P("Synthetic course data (CDB601220). Figure: partD_figure.png; every rule below is logged in partD_log.txt.", "claim")

    P("1 · Each panel: the question, the chart, the channel", "sec")
    P(lab("P1 daily sessions.") + "<i>Is traffic growing, and when did it move?</i> A line, because time is continuous and the question is shape. "
      "Raw series in light grey, the 7-day mean in blue: Week 2's rule of one pop-out and grey for context. Both are read by position along a common "
      "scale, the top of the channel ranking.")
    P(lab("P2 weekday x hour heatmap.") + "<i>When in the week do people arrive?</i> Two categorical axes and 168 cells; a single-hue sequential scale "
      "(no midpoint). Colour intensity is a weaker channel than position, so the title carries the number "
      "(Sat 20:00 = 2,336/h vs 1,713 on Mon-Thu).")
    P(lab("P3 treemap.") + "<i>Where is the mass?</i> Containment shows the category-to-sub-category hierarchy; one hue per parent, "
      "every block labelled with its value. Area is the fourth-best channel (position &gt; length &gt; angle &gt; area), so it is used for "
      "where, never for how much.")
    P(lab("P4 sorted bars.") + "<i>By how much, and in what order?</i> The same eight numbers as length from a zero baseline with values printed: "
      "the precise answer the treemap cannot give (Phones leads Laptops by PKR 112m).")

    P("2 · Every time decision", "sec")
    P(lab("Parse.") + "Two loggers: 9,019 rows ISO, 3,651 rows slash. 2,151 slash rows have a first field above 12 (up to 31), so the slash logger "
      "is <b>DD/MM/YYYY</b>; both formats parsed with explicit format strings, never format=\"mixed\". Month-first would give "
      "2024-01-04 to 2025-12-08 and 2,151 NaT; correct span 2024-04-01 to 2025-09-11, which agrees with the ISO rows.")
    P(lab("Aggregation.") + "Sessions are a <b>flow</b>, so hourly to daily is <b>sum</b>, on the de-duplicated, filled hourly series, with "
      "min_count=1 so an unrecorded day is NaN, not 0. Axis label says \"Sessions per day (sum of hourly counts)\".")
    P(lab("Gaps.") + "Counted on the <b>hourly</b> index before resampling: 312 missing hours = 13 whole days, drawn as line breaks with markers. "
      "September 2025 has 11 of 30 days and is shaded as partial.")
    P(lab("Window.") + "<b>7 days, centred</b>, min_periods 4. It cancels the weekly cycle (weekend lift 36% over Mon-Thu). Centred because the Monday "
      "review is retrospective; a live view would need a trailing mean, which lags by half a window (Part B.4: 15 days for 31).")
    P(lab("Window choice (the ethics clause).") + "The window was fixed at 7 days before plotting, because the cycle being removed is weekly (Part B.1). "
      "The series is shown from its first recorded day; no start date was selected. A 28-day version is in the appendix "
      "(partD_appendix_28day.png) and does not change the direction (slopes +21.47 vs +21.45 sessions/day per day).")
    P(lab("Part B.5, stated against myself.") + "On this one series 45 of 60 start x window combinations rise and 15 fall; every falling one starts "
      "Oct-Dec 2024, i.e. at the Black Friday / seasonal peak. Nobody reading the figure can see the combinations I did not draw, so the "
      "choice above is made on the cycle, not on the look. Symmetry test: had a different window weakened my conclusion I would still have used 7 "
      "days; the 28-day check was drawn because it could have contradicted it.")

    P("3 · Every row removed (rule, count, what moved)", "sec")
    P("&bull; <b>Duplicate hours: 286</b> (identical values; 121 written once per format). Rows 12,670 to 12,384; total sessions 12,010,544 to 11,726,873 (-2.4%, "
      "it would have been double-counted). &bull; <b>Sentinel -1 sessions: 287</b> (290 before de-duplication) set to missing, then filled for daily sums: "
      "270 by the mean of the two neighbouring hours, 17 by the weekday-hour median; 2.3% of sessions, total to 12,002,107. "
      "&bull; <b>Device labels</b> (Mobile / mobile / 'MOBILE ' etc.) harmonised to 3 classes; no rows lost. &bull; <b>Catalogue: 1 SKU row</b> "
      "(SKU-0127 appears under Audio and under Wearables; the name prefix AUDI marks Audio as the real parent): 345 to 344 rows, net revenue PKR 1,726.2m to "
      "1,711.4m; left in, Wearables would be 0.93 points out against shares_eight.csv, with it removed the largest gap is 0.24. "
      "&bull; <b>Negative net revenue: 7 SKUs, PKR -1.07m</b>, netted inside their sub-category totals (an honest net includes loss-makers) and never "
      "drawn as area.")

    P("4 · Every level rolled up", "sec")
    P("344 SKUs roll up to 8 sub-categories under 4 categories; the depth is cut at sub-category, since 344 blocks exceed the 4 +/- 1 chunk limit. "
      "No <b>Other</b> bucket was needed: the smallest sub-category (Drones, 2.4%) is above the 1% cut-off, so 0 categories and PKR 0 were folded. "
      "The treemap and bars use the same eight numbers.")
    doc.build(s)


if __name__ == "__main__":
    build_A()
    build_E()
    from pypdf import PdfReader
    for f in ("partA_diagnosis.pdf", "partE_justification.pdf"):
        print(f, len(PdfReader(HERE / f).pages), "pages")
