"""
partA_charts.py -- Week 4, Part A: nine published charts, rebuilt and redesigned.

Run:  python3 partA_charts.py
Out:  partA_case01.png ... partA_case09.png   (left = as published, right = redesign)
      partA_numbers.json                      (every number quoted in the diagnosis)

Each case first rebuilds the analyst's chart from the recipe and asserts the
self-check number from TASKS.md, then draws the honest chart. Every mark is
drawn on a named `ax`; there is no plt.plot()/plt.bar().
"""
from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.gridspec import GridSpecFromSubplotSpec

from tslib import PALETTE, style_defaults, save_fig, audit_index

warnings.filterwarnings("ignore", category=FutureWarning)
HERE = Path(__file__).parent
DATA = HERE / "data"
C = PALETTE["series"]          # blue, orange, green
GREY, INK, SOFT = PALETTE["muted"], PALETTE["ink"], PALETTE["ink_soft"]
SRC = "Synthetic course data (CDB601220, Week 4). Left: as published. Right: redesign."
N = {}                         # every number the diagnosis quotes


def datefmt(ax, days=None, fmt="%d %b"):
    """Few, readable date ticks: every `days` days, or one per year if None."""
    loc = mdates.DayLocator(interval=days) if days else mdates.YearLocator()
    ax.xaxis.set_major_locator(loc)
    ax.xaxis.set_major_formatter(mdates.DateFormatter(fmt if days else "%Y"))


def despine(ax):
    for sp in ax.spines.values():
        sp.set_visible(False)


def two_panel(title_l, title_r, w=15.5, h=5.2, ratios=(1, 1)):
    fig = plt.figure(figsize=(w, h), constrained_layout=True)
    gs = fig.add_gridspec(1, 2, width_ratios=ratios)
    return fig, fig.add_subplot(gs[0, 0]), gs


# ------------------------------------------------------------------ case 1
def case01():
    d = pd.read_csv(DATA / "case01_orders_stringdate.csv")
    pub = d.sort_values("month")                         # STRING sort
    drops = pub.orders.diff()
    assert len(pub) == 24 and sorted(-drops[drops < 0])[::-1] == [978, 958]
    first_run = int((pub.orders.diff().iloc[1:] > 0).cumprod().sum())
    fix = d.assign(dt=pd.to_datetime(d.month + "-01")).sort_values("dt")
    assert fix.orders.is_monotonic_increasing
    N["c1"] = dict(order_published=pub.month.tolist()[:6],
                   drops=[958, 978], first_climb_points=first_run + 1,
                   start=int(fix.orders.iloc[0]), end=int(fix.orders.iloc[-1]),
                   growth_pct=round((fix.orders.iloc[-1] / fix.orders.iloc[0] - 1) * 100, 1),
                   falling_months=int((fix.orders.diff() < 0).sum()),
                   mean_step=round(float(fix.orders.diff().mean()), 1))

    fig, ax, gs = two_panel("", "")
    ax.plot(range(24), pub.orders, color=C[0], marker="o")
    ax.set_xticks(range(24))
    ax.set_xticklabels(pub.month, rotation=90, fontsize=7)
    ax.set_ylim(0, 7000)
    ax.set_title('As published: "orders peak in Q1 and collapse every year"')
    ax.set_ylabel("Orders per month")
    ax.set_xlabel("month, sorted as TEXT: '2024-1' < '2024-10' < '2024-2'")
    despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(fix.dt, fix.orders, color=C[0], marker="o")
    ax2.set_ylim(0, 7000)
    ax2.set_title(f"Redesign: dates parsed, then sorted: orders rise every month, "
                  f"{N['c1']['start']:,} to {N['c1']['end']:,} (+{N['c1']['growth_pct']}%)")
    ax2.set_ylabel("Orders per month (sum over the month)")
    ax2.set_xlabel("Month (parsed to a real date, then sorted)")
    despine(ax2)
    save_fig(fig, HERE / "partA_case01.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 2
def case02():
    d = pd.read_csv(DATA / "case02_shop_closed.csv", parse_dates=["date"])
    x = np.arange(len(d))
    m, b = np.polyfit(x, d.sales_pkr_k, 1)
    assert len(d) == 69 and d.sales_pkr_k.iloc[0] == 207 and d.sales_pkr_k.iloc[-1] == 253
    rise = (253 / 207 - 1) * 100
    gap = d.date.diff().dt.days
    gi = gap[gap > 1].index[0]
    g0, g1 = d.date[gi - 1], d.date[gi]
    pre, post = d[d.date < g1].sales_pkr_k, d[d.date >= g1].sales_pkr_k
    xd = (d.date - d.date.min()).dt.days
    m_day = np.polyfit(xd, d.sales_pkr_k, 1)[0]
    # within-segment slopes: is there ANY steady growth inside either block?
    s_pre = np.polyfit(xd[d.date < g1], pre, 1)[0]
    s_post = np.polyfit(xd[d.date >= g1], post, 1)[0]
    N["c2"] = dict(rows=69, calendar_days=int(xd.max() + 1),
                   closed_days=int(xd.max() + 1 - len(d)),
                   gap_from=str(g0.date()), gap_to=str(g1.date()),
                   gap_days=int(gap[gi]), rise_pct=round(rise, 1),
                   pre_mean=round(float(pre.mean()), 1), post_mean=round(float(post.mean()), 1),
                   step_pct=round((post.mean() / pre.mean() - 1) * 100, 1),
                   slope_per_row=round(m, 3), slope_per_day=round(m_day, 3),
                   slope_pre=round(s_pre, 3), slope_post=round(s_post, 3),
                   sales_before_gap=int(d.sales_pkr_k[gi - 1]), sales_after_gap=int(d.sales_pkr_k[gi]))

    fig, ax, gs = two_panel("", "")
    ax.plot(x, d.sales_pkr_k, color=C[0], marker="o", markersize=3)
    ax.plot(x, m * x + b, color=C[1], linestyle="--", label=f"trend {m:+.2f} per row")
    ax.set_title('As published: "Sales grew steadily, +22%" (x = row number)')
    ax.set_xlabel("Row number (the 21 closed days do not exist on this axis)")
    ax.set_ylabel("Sales (PKR thousand per day)")
    ax.set_ylim(0, 300); ax.legend(loc="lower right"); despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    full = d.set_index("date").sales_pkr_k.asfreq("D")
    ax2.plot(full.index, full.values, color=C[0], marker="o", markersize=3)
    ax2.axvspan(g0 + pd.Timedelta(days=1), g1 - pd.Timedelta(days=1), color=PALETTE["grid"])
    ax2.hlines(pre.mean(), d.date.min(), g0, color=C[1], linewidth=2.5)
    ax2.hlines(post.mean(), g1, d.date.max(), color=C[1], linewidth=2.5)
    ax2.text(d.date.min(), pre.mean() - 28, f"mean {pre.mean():.0f} before", color=C[1], fontsize=9)
    ax2.text(g1 + pd.Timedelta(days=3), post.mean() - 28, f"mean {post.mean():.0f} after", color=C[1], fontsize=9)
    ax2.text(g0 + pd.Timedelta(days=1), 40, f"{N['c2']['gap_days']}-day\nclosure", fontsize=9, color=SOFT)
    ax2.set_ylim(0, 300)
    ax2.set_title(f"Redesign: flat, then a {N['c2']['step_pct']:.0f}% step across the closure, then flat")
    ax2.set_xlabel("Calendar date (closed days left as a gap)")
    ax2.set_ylabel("Sales (PKR thousand per day)")
    despine(ax2)
    save_fig(fig, HERE / "partA_case02.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 3
def case03():
    d = pd.read_csv(DATA / "case03_bandwidth_levels.csv", parse_dates=["ts"]).set_index("ts")
    daily_sum = d.concurrent_users.resample("D").sum()
    jun, jul = daily_sum["2025-06"].mean(), daily_sum["2025-07"].mean()
    assert abs(jun - 8800) < 100 and abs(jul - 12500) < 100
    hrs = d.concurrent_users.resample("D").count()
    mean_h = d.concurrent_users.resample("D").mean()
    mx = d.concurrent_users.resample("D").max()
    mj, ml = d.concurrent_users["2025-06"].mean(), d.concurrent_users["2025-07"].mean()
    N["c3"] = dict(rows=len(d), expected_rows=61 * 24, missing_hours=61 * 24 - len(d),
                   jun_daily_sum=round(jun), jul_daily_sum=round(jul),
                   step_pct=round((jul / jun - 1) * 100, 1),
                   jun_hours=int(hrs["2025-06"].sum()), jul_hours=int(hrs["2025-07"].sum()),
                   jun_hours_per_day=round(float(hrs["2025-06"].mean()), 1),
                   jul_hours_per_day=round(float(hrs["2025-07"].mean()), 1),
                   jun_hour_mean=round(mj, 1), jul_hour_mean=round(ml, 1),
                   hour_mean_change_pct=round((ml / mj - 1) * 100, 1),
                   jun_peak_mean=round(float(mx["2025-06"].mean())), jul_peak_mean=round(float(mx["2025-07"].mean())),
                   first_full_day=str(hrs[hrs == 24].index.min().date()))

    fig = plt.figure(figsize=(15.5, 6), constrained_layout=True)
    gs = fig.add_gridspec(1, 2)
    ax = fig.add_subplot(gs[0, 0])
    ax.plot(daily_sum.index, daily_sum.values, color=C[0])
    ax.set_ylim(0, 16000)
    ax.set_title('As published: "Peak load jumped 43% overnight on 1 July"')
    ax.set_ylabel("Sum of hourly concurrent users per day")
    ax.set_xlabel("Date"); datefmt(ax, 14); despine(ax)
    sub = gs[0, 1].subgridspec(2, 1, height_ratios=[3, 1.2])
    a1, a2 = fig.add_subplot(sub[0]), fig.add_subplot(sub[1])
    mean_h = mean_h.where(hrs > 0)
    a1.plot(mean_h.index, mean_h.values, color=C[0], label="Mean of the hours recorded")
    a1.plot(mx.index, mx.values, color=C[1], label="Daily peak hour")
    a1.set_ylim(0, 900)
    a1.set_title(f"Redesign: mean hourly load {mj:.0f} to {ml:.0f} ({N['c3']['hour_mean_change_pct']:+.1f}%);\n"
                 "June had only 16.4 of 24 hours recorded per day")
    a1.set_ylabel("Concurrent users (level, per hour)")
    a1.legend(loc="upper left", ncol=2); datefmt(a1, 14); a1.set_xticklabels([]); despine(a1)
    a2.bar(hrs.index, hrs.values, color=GREY, width=0.9)
    a2.axhline(24, color=SOFT, linewidth=0.8)
    a2.set_ylim(0, 26); a2.set_ylabel("Hours\nrecorded/day")
    a2.set_xlabel("Date (a full day is 24 hours)"); datefmt(a2, 14); despine(a2)
    save_fig(fig, HERE / "partA_case03.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 4
def case04():
    s = pd.read_csv(DATA / "case04_intervention_lag.csv", parse_dates=["date"]).set_index("date").conversion_pct
    tr, ce = s.rolling(31).mean(), s.rolling(31, center=True).mean()
    assert tr.idxmin() == pd.Timestamp("2025-09-07")
    c7 = s.rolling(7, center=True).mean()
    lag = (tr.idxmin() - ce.idxmin()).days
    N["c4"] = dict(claim="2025-09-07", trailing_min=str(tr.idxmin().date()),
                   centred_min=str(ce.idxmin().date()), lag_days=int(lag), half_window=15,
                   c7_min=str(c7.idxmin().date()),
                   level_at_turn=round(float(ce.min()), 3),
                   end_level=round(float(s.iloc[-14:].mean()), 3))

    fig, ax, gs = two_panel("", "")
    ax.plot(s.index, s.values, color=GREY, alpha=0.6, linewidth=0.9, label="Raw daily conversion")
    ax.plot(tr.index, tr.values, color=C[0], linewidth=2.4, label="31-day trailing mean")
    ax.axvline(tr.idxmin(), color=C[1], linestyle="--")
    ax.text(tr.idxmin() + pd.Timedelta(days=3), s.max() * 0.97, "bottoms out 7 Sep", color=C[1], fontsize=9)
    ax.set_title('As published: "The new checkout flow started working on 7 September"')
    ax.set_ylabel("Conversion (% of sessions, daily)"); ax.set_xlabel("Date")
    ax.legend(loc="upper left"); despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(s.index, s.values, color=GREY, alpha=0.6, linewidth=0.9, label="Raw daily conversion")
    ax2.plot(tr.index, tr.values, color=C[0], linewidth=2, label="31-day trailing (finds turn late)")
    ax2.plot(ce.index, ce.values, color=C[2], linewidth=2.4, label="31-day centred (no delay)")
    ax2.axvline(ce.idxmin(), color=C[2], linestyle="--")
    ax2.axvline(tr.idxmin(), color=C[1], linestyle="--")
    ax2.annotate(f"{lag}-day lag = half the window",
                 xy=(tr.idxmin(), ce.min() + 0.02), xytext=(ce.idxmin() - pd.Timedelta(days=75), s.max() * 0.97),
                 arrowprops=dict(arrowstyle="->", color=SOFT), fontsize=9)
    ax2.set_title(f"Redesign: the turn is ~{ce.idxmin():%d %b}; the 7 Sep date is the window filling")
    ax2.set_ylabel("Conversion (% of sessions, daily)"); ax2.set_xlabel("Date")
    ax2.legend(loc="upper left"); despine(ax2)
    save_fig(fig, HERE / "partA_case04.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 5
def case05():
    d = pd.read_csv(DATA / "case05_revenue_window.csv")
    d["dt"] = pd.to_datetime(d.month + "-01")
    w = d[(d.dt >= "2025-05-01") & (d.dt <= "2025-11-01")]
    assert len(w) == 7 and w.revenue_pkr_m.iloc[0] == 158.8 and w.revenue_pkr_m.iloc[-1] == 92.2
    fall = (92.2 / 158.8 - 1) * 100
    d["yr"], d["mo"] = d.dt.dt.year, d.dt.dt.month
    pv = d.pivot(index="mo", columns="yr", values="revenue_pkr_m")
    yoy_may = (pv.loc[5, 2025] / pv.loc[5, 2024] - 1) * 100
    yoy_nov = (pv.loc[11, 2025] / pv.loc[11, 2024] - 1) * 100
    same_window_2024 = pv.loc[5:11, 2024]
    peak_months = pv.idxmax().to_dict()
    N["c5"] = dict(n=len(w), start=158.8, end=92.2, fall_pct=round(fall, 1),
                   same_window_2024_fall_pct=round((same_window_2024.iloc[-1] / same_window_2024.iloc[0] - 1) * 100, 1),
                   same_window_2023_fall_pct=round((pv.loc[11, 2023] / pv.loc[5, 2023] - 1) * 100, 1),
                   yoy_may=round(yoy_may, 1), yoy_nov=round(yoy_nov, 1),
                   peak_month_by_year={int(k): int(v) for k, v in peak_months.items()},
                   trough_month_by_year={int(k): int(v) for k, v in pv.idxmin().to_dict().items()},
                   annual_total={int(k): round(float(v), 1) for k, v in pv.sum().items()})

    fig, ax, gs = two_panel("", "")
    ax.plot(w.dt, w.revenue_pkr_m, color=C[0], marker="o")
    ax.set_ylim(0, 180)
    ax.set_title('As published: "Revenue has fallen for six straight months" (-41.9%)')
    ax.set_ylabel("Revenue (PKR m per month)"); ax.set_xlabel("Month (May to Nov 2025 only; n = 7)")
    despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    mn = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"]
    for yr, col, ls in zip([2023, 2024, 2025], [GREY, C[2], C[0]], ["-", "-", "-"]):
        yv = pv[yr]
        ax2.plot(pv.index, yv, color=col, marker="o", markersize=3.5, linewidth=2.4 if yr == 2025 else 1.6)
        ax2.text(12.15, yv.iloc[-1], str(yr), color=col, fontsize=9, va="center", fontweight="bold")
    ax2.axvspan(4.8, 11.2, color=PALETTE["grid"], alpha=0.8, zorder=0)
    ax2.text(8, 168, "the published window", ha="center", fontsize=9, color=SOFT)
    ax2.set_xticks(range(1, 13)); ax2.set_xticklabels(mn)
    ax2.set_xlim(0.7, 12.9); ax2.set_ylim(0, 180)
    ax2.set_title(f"Redesign: every year peaks in May-Jun and falls to Nov; Nov 2025 is "
                  f"{yoy_nov:+.0f}% on Nov 2024")
    ax2.set_ylabel("Revenue (PKR m per month)"); ax2.set_xlabel("Month of year")
    despine(ax2)
    save_fig(fig, HERE / "partA_case05.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 6
def case06():
    d = pd.read_csv(DATA / "case06_monthly_partial.csv", parse_dates=["date"]).set_index("date")
    m = d.orders.resample("MS").sum()
    n = d.orders.resample("MS").count()
    rate = d.orders.resample("MS").mean()
    assert len(m) == 10 and m.iloc[-2] == 10805 and m.iloc[-1] == 4041
    N["c6"] = dict(sep_total=int(m.iloc[-2]), oct_total=int(m.iloc[-1]),
                   oct_pct_of_sep=round(m.iloc[-1] / m.iloc[-2] * 100, 1),
                   oct_days=int(n.iloc[-1]), last_day=str(d.index.max().date()),
                   sep_rate=round(float(rate.iloc[-2]), 1), oct_rate=round(float(rate.iloc[-1]), 1),
                   rate_change_pct=round((rate.iloc[-1] / rate.iloc[-2] - 1) * 100, 1),
                   expected_oct_total_at_sep_rate=round(float(rate.iloc[-2] * 31)))

    fig, ax, gs = two_panel("", "")
    ax.bar(m.index, m.values, width=22, color=C[0])
    ax.set_title('As published: "Orders collapsed in October" (4,041 vs 10,805)')
    ax.set_ylabel("Orders per month (sum)"); ax.set_xlabel("Month"); ax.set_ylim(0, 12500)
    despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    cols = [C[0]] * 9 + ["white"]
    ax2.bar(rate.index, rate.values, width=22, color=cols, edgecolor=C[0], linewidth=1.5)
    ax2.patches[-1].set_hatch("///")
    ax2.text(rate.index[-1], rate.iloc[-1] + 12, f"partial: {n.iloc[-1]} of 31 days", ha="center",
             fontsize=9, color=SOFT)
    for x, v, k in zip(rate.index, rate.values, n.values):
        ax2.text(x, v / 2, f"{v:.0f}", ha="center", color="white" if k > 20 else INK, fontsize=9,
                 fontweight="bold")
    ax2.set_ylim(0, 450)
    ax2.set_title(f"Redesign: per-day orders are still rising; October is {N['c6']['rate_change_pct']:+.0f}% on September")
    ax2.set_ylabel("Orders per day (mean of recorded days)"); ax2.set_xlabel("Month (hatched = partial)")
    despine(ax2)
    save_fig(fig, HERE / "partA_case06.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 7
def case07():
    d = pd.read_csv(DATA / "case07_stacked_products.csv")
    d["dt"] = pd.to_datetime(d.month + "-01")
    cols = ["product_a", "product_b", "product_c", "product_d"]
    tot = d[cols].sum(axis=1)
    assert 547 < tot.min() < 549 and 708 < tot.max() < 710
    sd_level = d[cols].std()
    sd_step = d[cols].diff().std()
    N["c7"] = dict(total_min=round(float(tot.min()), 1), total_max=round(float(tot.max()), 1),
                   sd_step={c: round(float(v), 1) for c, v in sd_step.items()},
                   b_min=float(d.product_b.min()), b_max=float(d.product_b.max()),
                   d_min=float(d.product_d.min()), d_max=float(d.product_d.max()),
                   d_sd_step_since_2024_07=round(float(d.loc[d.dt >= "2024-07-01", "product_d"].diff().std()), 2),
                   b_sd_step_since_2024_07=round(float(d.loc[d.dt >= "2024-07-01", "product_b"].diff().std()), 2),
                   ratio_b_over_d=round(float(sd_step["product_b"] / sd_step["product_d"]), 1),
                   corr_b_with_c_top_edge=round(float(np.corrcoef(d.product_b, (d.product_a + d.product_b + d.product_c))[0, 1]), 2))
    fig = plt.figure(figsize=(15.5, 6), constrained_layout=True)
    gs = fig.add_gridspec(1, 2)
    ax = fig.add_subplot(gs[0, 0])
    ax.stackplot(d.dt, *[d[c] for c in cols], colors=[C[0], C[1], C[2], PALETTE["series_4th"]],
                 labels=["A", "B", "C", "D (top)"])
    ax.set_title('As published: "Product D has been erratic since mid-2024"')
    ax.set_ylabel("Revenue (PKR m per month)"); ax.set_xlabel("Month"); ax.legend(loc="upper left", ncol=4)
    ax.set_ylim(0, 800); despine(ax)
    sub = gs[0, 1].subgridspec(2, 2, hspace=0.12, wspace=0.08)
    ttl = {"product_a": "A", "product_b": "B: the erratic one", "product_c": "C", "product_d": "D: flat"}
    col = {"product_a": C[0], "product_b": C[1], "product_c": C[2], "product_d": PALETTE["series_4th"]}
    for i, c in enumerate(cols):
        a = fig.add_subplot(sub[i // 2, i % 2])
        a.plot(d.dt, d[c], color=col[c], marker="o", markersize=2.5)
        a.set_ylim(0, 300)
        a.set_title(f"{ttl[c]}  (step SD {sd_step[c]:.1f})", fontsize=10)
        if i % 2: a.set_yticklabels([])
        else: a.set_ylabel("PKR m / month")
        datefmt(a)
        if i // 2 == 0: a.set_xticklabels([])
        despine(a)
    fig.text(0.52, 1.03, "Redesign: unstacked, shared y-axis from zero. B swings, D barely moves",
             fontsize=12, fontweight="bold", ha="left")
    save_fig(fig, HERE / "partA_case07.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 8
def case08():
    d = pd.read_csv(DATA / "case08_channel_attrib.csv")
    tc = [c for c in d if c.startswith("touch_")]
    sh = d[tc].mean() * 100
    assert abs(sh.touch_search - 42.6) < 0.1 and abs(sh.touch_social - 32.3) < 0.1
    from tslib import exclusivity_check
    chk = exclusivity_check(d, tc)
    nt = d[tc].sum(axis=1).value_counts().sort_index()
    sole = {c.replace("touch_", ""): float(((d[c]) & (d[tc].sum(axis=1) == 1)).mean() * 100) for c in tc}
    N["c8"] = dict(n=chk["n"], shares=chk["shares_pct"], sum_pct=chk["sum_pct"], exclusive=chk["exclusive"],
                   n_multi=chk["n_multi"], pct_multi=chk["pct_multi"], n_zero=chk["n_zero"],
                   touches_hist={int(k): int(v) for k, v in nt.items()},
                   sole_touch_pct={k: round(v, 1) for k, v in sole.items()},
                   search_normalised_pct=round(float(sh.touch_search / sh.sum() * 100), 1))

    fig, ax, gs = two_panel("", "")
    names = [c.replace("touch_", "") for c in tc]
    ax.pie(sh.values, labels=[f"{n}\n{v:.1f}%" for n, v in zip(names, sh.values)],
           colors=[C[0], C[1], C[2], PALETTE["series_4th"]], startangle=90, counterclock=False,
           wedgeprops=dict(edgecolor="white"))
    ax.grid(False)
    ax.set_title('As published: "Paid search drives 43% of customers"')
    ax.text(0, -1.25, f"The four slices sum to {chk['sum_pct']:.1f}%, not 100%", ha="center", fontsize=9, color=SOFT)
    ax2 = fig.add_subplot(gs[0, 1])
    order = sh.sort_values()
    ax2.barh([c.replace("touch_", "") for c in order.index], order.values, color=C[0], height=0.6)
    ax2.barh([c.replace("touch_", "") for c in order.index],
             [sole[c.replace("touch_", "")] for c in order.index], color=C[1], height=0.6)
    for y, (c, v) in enumerate(order.items()):
        ax2.text(v + 0.8, y, f"{v:.1f}% touched   ({sole[c.replace('touch_', '')]:.1f}% sole touch)",
                 va="center", fontsize=9)
    ax2.set_xlim(0, 70); ax2.xaxis.grid(True); ax2.yaxis.grid(False)
    ax2.set_title(f"Redesign: reach, not a split ({chk['pct_multi']:.0f}% touched by 2+ channels)")
    ax2.set_xlabel("% of 4,000 customers touched (blue); orange = touched by that channel only")
    despine(ax2)
    save_fig(fig, HERE / "partA_case08.png", note=SRC)
    plt.close(fig)


# ------------------------------------------------------------------ case 9
def case09():
    d = pd.read_csv(DATA / "case09_premium_share.csv")
    d["share"] = d.premium_revenue_pkr_m / d.total_revenue_pkr_m * 100
    d["other"] = d.total_revenue_pkr_m - d.premium_revenue_pkr_m
    assert abs(d.share.iloc[0] - 24.0) < 1e-6 and abs(d.share.iloc[-1] - 38.0) < 1e-6
    N["c9"] = dict(share_first=24.0, share_last=38.0,
                   premium_first=float(d.premium_revenue_pkr_m.iloc[0]), premium_last=float(d.premium_revenue_pkr_m.iloc[-1]),
                   premium_change_pct=round((d.premium_revenue_pkr_m.iloc[-1] / d.premium_revenue_pkr_m.iloc[0] - 1) * 100, 1),
                   total_first=float(d.total_revenue_pkr_m.iloc[0]), total_last=float(d.total_revenue_pkr_m.iloc[-1]),
                   total_change_pct=round((d.total_revenue_pkr_m.iloc[-1] / d.total_revenue_pkr_m.iloc[0] - 1) * 100, 1),
                   other_first=float(d.other.iloc[0]), other_last=float(d.other.iloc[-1]),
                   other_change_pct=round((d.other.iloc[-1] / d.other.iloc[0] - 1) * 100, 1),
                   premium_peak=float(d.premium_revenue_pkr_m.max()), premium_peak_q=d.quarter[d.premium_revenue_pkr_m.idxmax()],
                   share_if_premium_flat_at_first=round(240 / d.total_revenue_pkr_m.iloc[-1] * 100, 1))
    fig, ax, gs = two_panel("", "")
    ax.plot(d.quarter, d.share, color=C[0], marker="o")
    ax.annotate("38.0%: a record", xy=(7, 38), xytext=(4.2, 41), arrowprops=dict(arrowstyle="->", color=SOFT), fontsize=9)
    ax.set_ylim(0, 45)
    ax.set_title('As published: "Premium is now 38% of revenue, a record"')
    ax.set_ylabel("Premium share of revenue (%)"); ax.set_xlabel("Quarter"); despine(ax)
    ax2 = fig.add_subplot(gs[0, 1])
    ax2.plot(d.quarter, d.other, color=GREY, marker="s", linewidth=2.4)
    ax2.plot(d.quarter, d.premium_revenue_pkr_m, color=C[0], marker="o", linewidth=2.4)
    ax2.text(7.15, d.other.iloc[-1], f"Other {d.other.iloc[-1]:.0f}\n({N['c9']['other_change_pct']:+.0f}%)", color=SOFT, fontsize=9, va="center")
    ax2.text(7.15, d.premium_revenue_pkr_m.iloc[-1], f"Premium {d.premium_revenue_pkr_m.iloc[-1]:.0f}\n({N['c9']['premium_change_pct']:+.0f}%)", color=C[0], fontsize=9, va="center")
    ax2.set_xlim(-0.3, 8.1); ax2.set_ylim(0, 850)
    ax2.set_title("Redesign: the share rose because the rest of the business fell, not because premium grew")
    ax2.set_ylabel("Revenue (PKR m per quarter)"); ax2.set_xlabel("Quarter"); despine(ax2)
    save_fig(fig, HERE / "partA_case09.png", note=SRC)
    plt.close(fig)


def main():
    style_defaults()
    for f in (case01, case02, case03, case04, case05, case06, case07, case08, case09):
        f()
        print(f.__name__, "ok")
    (HERE / "partA_numbers.json").write_text(json.dumps(N, indent=2), encoding="utf-8")
    print(json.dumps(N, indent=1))


if __name__ == "__main__":
    main()
