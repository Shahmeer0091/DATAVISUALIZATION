"""
partD_figure.py -- Week 4, Part D: the e-commerce Monday-review figure.

Run:  python3 partD_figure.py
Out:  partD_figure.png            (2x2, 300 dpi)
      partD_appendix_28day.png    (the 28-day check named in Part E)
      partD_log.txt               (every rule applied, with counts)

Every data rule lives in clean_sessions.py and is logged, not remembered.
Nothing here uses plt.plot()/plt.bar(): every mark is drawn on a named `ax`.
"""
from pathlib import Path
import sys
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import to_rgb
from matplotlib.patches import Rectangle
import squarify

from clean_sessions import load_clean_sessions, DATA
from tslib import PALETTE, style_defaults, save_fig, audit_index

warnings.filterwarnings("ignore", category=FutureWarning)
HERE = Path(__file__).parent
WINDOW = 7          # fixed BEFORE plotting: the cycle to cancel is weekly (Part B.1)
MIN_PERIODS = 4     # a window needs >= 4 of its 7 days, so a gap does not erase a week

# one hue per parent category (Okabe-Ito). The 4th hue is below 3:1 contrast
# on white, so every block carries a direct label -- nothing relies on colour.
CAT_HUE = {"Mobile": PALETTE["series"][0],
           "Audio & Imaging": PALETTE["series_4th"],
           "Lifestyle": PALETTE["series"][2],
           "Computing": PALETTE["series"][1]}


# ----------------------------------------------------------------- helpers
def tint(hex_colour, amount):
    """Mix a colour with white. amount=0 -> original, 1 -> white."""
    r, g, b = to_rgb(hex_colour)
    return (r + (1 - r) * amount, g + (1 - g) * amount, b + (1 - b) * amount)


def despine(ax):
    for sp in ax.spines.values():
        sp.set_visible(False)


def load_catalogue():
    """The hierarchy as a tree: one parent per child, children sum to parent."""
    cat = pd.read_csv(DATA / "revenue_catalogue.csv")
    clog = {"rows_in": len(cat)}
    # duplicate SKU: SKU-0127 'AUDI-04' appears under Audio AND under Wearables.
    # The SKU-name prefix says which parent is real, so keep that one.
    prefix = cat.sku_name.str.split("-").str[0]
    sub_prefix = cat.subcategory.str.upper().str[:4]
    dup = cat.sku.duplicated(keep=False)
    wrong_parent = dup & (prefix != sub_prefix)
    clog["duplicate_sku_rows_removed"] = int(wrong_parent.sum())
    clog["duplicate_sku"] = cat.loc[dup, "sku"].unique().tolist()
    cat = cat[~wrong_parent].copy()
    assert not cat.sku.duplicated().any()
    assert (cat.groupby("subcategory").category.nunique() == 1).all()  # a tree
    # negative net revenue: kept INSIDE the sub-category total (a sub-category's
    # honest net includes its loss-making SKUs) but never drawn as an area.
    neg = cat[cat.net_revenue_pkr_m < 0]
    clog["negative_rows"] = int(len(neg))
    clog["negative_total_pkr_m"] = round(float(neg.net_revenue_pkr_m.sum()), 3)
    sub = (cat.groupby(["category", "subcategory"]).net_revenue_pkr_m.sum()
              .reset_index())
    assert (sub.net_revenue_pkr_m > 0).all(), "a leaf has no area"
    clog["rows_out"] = int(len(cat))
    clog["total_net_pkr_m"] = round(float(sub.net_revenue_pkr_m.sum()), 2)
    # self-check against shares_eight.csv
    ref = pd.read_csv(DATA / "shares_eight.csv").set_index("subcategory").share_pct
    mine = sub.set_index("subcategory").net_revenue_pkr_m
    mine = mine / mine.sum() * 100
    clog["max_gap_vs_shares_eight_pp"] = round(float((mine - ref).abs().max()), 3)
    assert clog["max_gap_vs_shares_eight_pp"] < 0.3
    return cat, sub, clog


def nested_treemap(ax, sub, pad=0.7):
    """Two-level squarified treemap: categories first, sub-categories inside.
    One hue per parent; every block carries its value in text (Week 2: area is
    the fourth-best channel, so the number does the precise work)."""
    total = sub.net_revenue_pkr_m.sum()
    cats = (sub.groupby("category").net_revenue_pkr_m.sum()
               .sort_values(ascending=False))
    top = squarify.squarify(squarify.normalize_sizes(cats.values, 100, 100),
                            0, 0, 100, 100)
    for r, (cname, cval) in zip(top, cats.items()):
        kids = (sub[sub.category == cname]
                .sort_values("net_revenue_pkr_m", ascending=False))
        inner = squarify.squarify(
            squarify.normalize_sizes(kids.net_revenue_pkr_m.values,
                                     r["dx"], r["dy"]),
            r["x"], r["y"], r["dx"], r["dy"])
        for j, (kr, (_, k)) in enumerate(zip(inner, kids.iterrows())):
            shade = tint(CAT_HUE[cname], 0.0 + 0.22 * j)
            ax.add_patch(Rectangle((kr["x"], kr["y"]), kr["dx"] - pad,
                                   kr["dy"] - pad, facecolor=shade,
                                   edgecolor="white", linewidth=1.0))
            share = k.net_revenue_pkr_m / total * 100
            if kr["dx"] > 11 and kr["dy"] > 9:
                ax.text(kr["x"] + (kr["dx"] - pad) / 2,
                        kr["y"] + (kr["dy"] - pad) / 2,
                        f"{k.subcategory}\n{k.net_revenue_pkr_m:,.0f}\n{share:.1f}%",
                        ha="center", va="center", fontsize=8.5,
                        color="white", linespacing=1.3, fontweight="bold")
            else:   # too small for a label inside: print it beside the block
                ax.text(kr["x"] + 0.8, kr["y"] + 2.6,
                        f"{k.subcategory} {k.net_revenue_pkr_m:,.0f} ({share:.1f}%)",
                        ha="left", va="center", fontsize=7.5, color="white",
                        fontweight="bold")
        # parent frame + parent label in its own colour, above the block
        ax.add_patch(Rectangle((r["x"], r["y"]), r["dx"] - pad, r["dy"] - pad,
                               facecolor="none", edgecolor=CAT_HUE[cname],
                               linewidth=2.2))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.invert_yaxis()
    ax.axis("off")
    return cats


# ------------------------------------------------------------------ main
def main():
    style_defaults()
    log_lines = []

    def log(msg=""):
        print(msg)
        log_lines.append(msg)

    # ===== sessions: clean ================================================
    hourly, daily, slog = load_clean_sessions()
    s = daily["sessions"]
    assert s.index.is_monotonic_increasing and s.index.freqstr == "D"

    log("=== sessions_hourly.csv ===")
    for k in ["rows_in", "n_iso", "n_slash", "slash_first_field_gt12", "span",
              "span_if_month_first", "n_duplicates", "dup_identical_values",
              "dup_pairs_across_formats", "device_before", "device_after",
              "n_sentinel", "n_imputed_by_neighbour_mean",
              "n_imputed_by_weekday_hour_median", "imputed_share_of_sessions_pct",
              "expected_hours", "missing_hours", "missing_days", "rows_out",
              "partial_month", "partial_days_present", "partial_days_in_month"]:
        log(f"  {k}: {slog[k]}")
    aud = audit_index(hourly, "h")
    log(f"  audit_index(hourly): {aud}")
    aud_d = audit_index(s.dropna(), "D")
    log(f"  audit_index(daily, recorded days): missing={aud_d['n_missing']}")

    missing_days = pd.to_datetime(slog["missing_days"])
    roll = s.rolling(WINDOW, center=True, min_periods=MIN_PERIODS).mean()

    # ===== catalogue: clean ===============================================
    cat, sub, clog = load_catalogue()
    log("=== revenue_catalogue.csv ===")
    for k, v in clog.items():
        log(f"  {k}: {v}")

    # ===== numbers that the titles quote ==================================
    monthly_mean = s.resample("MS").mean()
    apr24, nov24 = monthly_mean["2024-04-01"], monthly_mean["2024-11-01"]
    may25, aug25 = monthly_mean["2025-05-01"], monthly_mean["2025-08-01"]
    bf = s.loc["2024-11-29"]
    wk = s.groupby(s.index.dayofweek).mean()
    weekend_lift = (wk[[5, 6]].mean() / wk[[0, 1, 2, 3]].mean() - 1) * 100
    log("=== numbers quoted on the figure ===")
    log(f"  monthly mean sessions/day Apr24={apr24:,.0f} Nov24={nov24:,.0f} "
        f"May25={may25:,.0f} Aug25={aug25:,.0f}")
    log(f"  Black Friday 2024-11-29 = {bf:,.0f}; weekend lift vs Mon-Thu = "
        f"{weekend_lift:.0f}%")

    # heatmap: mean sessions per hour, by weekday x hour (sentinel hours NaN)
    hm = (hourly.assign(dow=hourly.index.dayofweek, hr=hourly.index.hour)
                .pivot_table(index="dow", columns="hr", values="sessions",
                             aggfunc="mean"))
    peak_dow, peak_hr = np.unravel_index(np.nanargmax(hm.values), hm.shape)
    dnames = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    wkday_same_hr = hm.loc[0:3, peak_hr].mean()
    log(f"  heatmap peak {dnames[peak_dow]} {peak_hr}:00 = "
        f"{hm.values[peak_dow, peak_hr]:,.0f}/h vs Mon-Thu same hour "
        f"{wkday_same_hr:,.0f}/h")
    night = hm.loc[:, 3:5].values.mean()
    log(f"  mean sessions/h at 03-05h = {night:,.0f}")

    # ===== FIGURE ==========================================================
    fig = plt.figure(figsize=(17, 11.2), constrained_layout=True)
    gs = fig.add_gridspec(2, 2, width_ratios=[1.12, 1])
    ax1 = fig.add_subplot(gs[0, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[1, 0])
    ax4 = fig.add_subplot(gs[1, 1])

    # ---- panel 1: daily series, raw grey, 7-day mean on top ---------------
    YMAX = 60_000
    ax1.plot(s.index, s.values, color=PALETTE["muted"], alpha=0.55,
             linewidth=0.9, label="Raw daily sessions")
    ax1.plot(roll.index, roll.values, color=PALETTE["series"][0], linewidth=2.4,
             label=f"{WINDOW}-day centred rolling mean (cancels the weekly cycle)")
    ax1.set_ylim(0, YMAX)
    ax1.vlines(missing_days, 0, 2200, color=PALETTE["highlight"], linewidth=1.6,
               label=f"{len(missing_days)} unrecorded days (line breaks)")
    last = s.index.max()
    ax1.axvspan(pd.Timestamp(last.year, last.month, 1), last + pd.Timedelta(days=1),
                color=PALETTE["grid"], alpha=0.9, zorder=0)
    ax1.text(pd.Timestamp(last.year, last.month, 1) - pd.Timedelta(days=5), YMAX * 0.93,
             f"Sep 2025: partial month\n({slog['partial_days_present']} of "
             f"{slog['partial_days_in_month']} days)", ha="right", va="top",
             fontsize=8, color=PALETTE["ink_soft"])
    ax1.annotate(f"Black Friday 29 Nov 2024:\n{bf:,.0f} sessions (above scale)",
                 xy=(pd.Timestamp("2024-11-29"), YMAX),
                 xytext=(pd.Timestamp("2024-08-10"), YMAX * 0.90),
                 fontsize=8.5, color=PALETTE["ink"], ha="center", va="top",
                 arrowprops=dict(arrowstyle="->", color=PALETTE["ink_soft"]))
    ax1.set_title(f"Traffic follows a seasonal arc: {apr24/1e3:.0f}k/day (Apr 24) → "
                  f"{nov24/1e3:.0f}k (Nov 24) → {may25/1e3:.0f}k (May 25) → "
                  f"{aug25/1e3:.0f}k (Aug 25)\n"
                  f"Raw daily line vs {WINDOW}-day centred rolling mean",
                  fontsize=11)
    ax1.set_ylabel("Sessions per day (sum of hourly counts)")
    ax1.set_xlabel("Date (first recorded day to last; no start date selected)")
    ax1.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(
        lambda v, _: f"{v/1e3:.0f}k"))
    ax1.legend(loc="upper left", fontsize=8, bbox_to_anchor=(0.0, 0.84))
    despine(ax1)

    # ---- panel 2: weekday x hour heatmap (sequential) ---------------------
    im = ax2.imshow(hm.values, aspect="auto", cmap=PALETTE["sequential"])
    ax2.set_xticks(range(0, 24, 3))
    ax2.set_xticklabels([f"{h:02d}:00" for h in range(0, 24, 3)])
    ax2.set_yticks(range(7))
    ax2.set_yticklabels(dnames)
    ax2.grid(False)
    ax2.set_title(f"Weekend evenings are the peak: {dnames[peak_dow]} "
                  f"{peak_hr}:00 averages {hm.values[peak_dow, peak_hr]:,.0f} sessions/h,\n"
                  f"vs {wkday_same_hr:,.0f} on Mon–Thu at the same hour", fontsize=11)
    ax2.set_xlabel("Hour of day (local time)")
    ax2.set_ylabel("Day of week")
    cb = fig.colorbar(im, ax=ax2, shrink=0.85, pad=0.02)
    cb.set_label("Mean sessions per hour")
    cb.outline.set_visible(False)
    despine(ax2)

    # ---- panel 3: treemap category -> sub-category ------------------------
    cats = nested_treemap(ax3, sub)
    tot = cats.sum()
    top = cats.index[0]
    ax3.set_title(f"{top} is the biggest block: {cats.iloc[0] / tot * 100:.0f}% of "
                  f"PKR {tot:,.0f}m net revenue; the colour = parent, area = value\n"
                  "Block text: sub-category, net revenue (PKR m), share of total",
                  fontsize=11)
    # parent legend, direct-labelled
    for i, (c, v) in enumerate(cats.items()):
        ax3.text(0 + i * 25, 104.5, f"■ {c} {v / tot * 100:.0f}%", color=CAT_HUE[c],
                 fontsize=9, fontweight="bold", ha="left", va="top",
                 clip_on=False)

    # ---- panel 4: the same eight as sorted bars, values printed -----------
    bars = sub.sort_values("net_revenue_pkr_m")
    y = np.arange(len(bars))
    ax4.barh(y, bars.net_revenue_pkr_m, color=[CAT_HUE[c] for c in bars.category],
             height=0.68)
    for yi, (_, r) in zip(y, bars.iterrows()):
        ax4.text(r.net_revenue_pkr_m + tot * 0.006, yi,
                 f"{r.net_revenue_pkr_m:,.0f}  ({r.net_revenue_pkr_m / tot * 100:.1f}%)",
                 va="center", fontsize=9, color=PALETTE["ink"])
    ax4.set_yticks(y)
    ax4.set_yticklabels(bars.subcategory)
    ax4.set_xlim(0, bars.net_revenue_pkr_m.max() * 1.22)
    ax4.xaxis.grid(True)
    ax4.yaxis.grid(False)
    lead, runner = bars.iloc[-1], bars.iloc[-2]
    ax4.set_title(f"{lead.subcategory} leads {runner.subcategory} by PKR "
                  f"{lead.net_revenue_pkr_m - runner.net_revenue_pkr_m:,.0f}m; "
                  f"{bars.iloc[0].subcategory} is the smallest at "
                  f"{bars.iloc[0].net_revenue_pkr_m / tot * 100:.1f}%\n"
                  "Same eight sub-categories, sorted, bars from zero", fontsize=11)
    ax4.set_xlabel("Net revenue (PKR m, sum over the extract)")
    handles = [Rectangle((0, 0), 1, 1, color=CAT_HUE[c]) for c in cats.index]
    ax4.legend(handles, list(cats.index), loc="lower right", fontsize=8.5,
               title="Parent category", title_fontsize=8.5)
    despine(ax4)

    note = (
        "Source: synthetic course data (CDB601220, Week 4); sessions_hourly.csv + revenue_catalogue.csv. "
        f"Sessions: {slog['rows_in']:,} rows -> {slog['rows_out']:,} after removing {slog['n_duplicates']} exact "
        f"duplicate hours; 2 timestamp formats parsed explicitly (DD/MM/YYYY for the slash logger); "
        f"{slog['n_sentinel']} sentinel (-1) hours set to missing and filled for daily sums "
        f"({slog['n_imputed_hours']} h = {slog['imputed_share_of_sessions_pct']:.1f}% of sessions); "
        f"{len(missing_days)} unrecorded days left as gaps.\n"
        f"Catalogue: {clog['rows_in']} SKU rows -> {clog['rows_out']} (1 duplicate SKU removed); "
        f"{clog['negative_rows']} SKUs with negative net revenue (PKR {clog['negative_total_pkr_m']}m) are netted "
        "inside their sub-category and not drawn as area; 344 SKUs rolled up to 8 sub-categories, "
        "no 'Other' bucket needed. Heatmap: mean of hourly sessions, sentinel hours excluded.")
    fig.suptitle("E-commerce Monday review: weekly rhythm stripped out, catalogue shown two ways",
                 fontsize=15, fontweight="bold", x=0.01, ha="left")
    out = save_fig(fig, HERE / "partD_figure.png", note=note)
    plt.close(fig)
    log(f"saved {out}")

    # ===== appendix: the 28-day version named in Part E ====================
    roll28 = s.rolling(28, center=True, min_periods=14).mean()
    xnum = np.arange(len(s))

    def slope(sm):
        m = sm.notna().to_numpy()
        return np.polyfit(xnum[m], sm.to_numpy()[m], 1)[0]

    log("=== appendix: window sensitivity of direction ===")
    log(f"  linear slope of 7-day mean over full span: {slope(roll):+.2f} sessions/day per day")
    log(f"  linear slope of 28-day mean over full span: {slope(roll28):+.2f} sessions/day per day")
    first_full = roll.dropna().iloc[0]
    log(f"  7-day mean first/last valid: {roll.dropna().iloc[0]:,.0f} -> {roll.dropna().iloc[-1]:,.0f}")
    log(f"  28-day mean first/last valid: {roll28.dropna().iloc[0]:,.0f} -> {roll28.dropna().iloc[-1]:,.0f}")
    same_dir = np.sign(slope(roll)) == np.sign(slope(roll28))
    log(f"  same direction: {same_dir}")

    fig2 = plt.figure(figsize=(9, 3.8), constrained_layout=True)
    a = fig2.add_subplot(1, 1, 1)
    a.plot(s.index, s.values, color=PALETTE["muted"], alpha=0.5, linewidth=0.8,
           label="Raw daily sessions")
    a.plot(roll.index, roll.values, color=PALETTE["series"][0], linewidth=1.8,
           label="7-day centred rolling mean (used in Part D)")
    a.plot(roll28.index, roll28.values, color=PALETTE["highlight"], linewidth=2.2,
           label="28-day centred rolling mean (appendix)")
    a.set_ylim(0, YMAX)
    a.set_ylabel("Sessions per day (sum of hourly counts)")
    a.set_title("Appendix: a 28-day window keeps the same direction as the 7-day window",
                fontsize=11)
    a.legend(loc="upper left", fontsize=8)
    despine(a)
    save_fig(fig2, HERE / "partD_appendix_28day.png",
             note="Same cleaned series as partD_figure.png. Synthetic course data (CDB601220).")
    plt.close(fig2)

    (HERE / "partD_log.txt").write_text("\n".join(log_lines), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())