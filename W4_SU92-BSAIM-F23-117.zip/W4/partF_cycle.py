"""
partF_cycle.py -- Week 4, Part F (bonus): is the growing seasonal swing real
seasonality, or just a growing level?   Trend vs cycle, settled with a number.

Usage (your own data, >= 18 months, a source you cite and the date downloaded):
    python3 partF_cycle.py data.csv --date DATECOL --value VALCOL \
        [--category CATCOL --keep "Some category"] \
        --source "Publisher, title, URL" --downloaded 2026-10-19

    python3 partF_cycle.py --demo      # self-test on Week 1's flights.csv (NOT your Part F data)

Out: partF_cycle.png (three panels: banked series, cycle plot, additive vs
multiplicative residuals) and the printed audit + two-sentence answer.
"""
from pathlib import Path
import argparse
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from tslib import PALETTE, style_defaults, save_fig, audit_index, banked_figsize, cycle_plot

HERE = Path(__file__).parent
C = PALETTE["series"]


def decompose(y, period, model):
    """Classical decomposition (centred MA trend); additive or multiplicative."""
    w = np.r_[0.5, np.ones(period - 1), 0.5] / period if period % 2 == 0 else np.ones(period) / period
    k = (len(w) - 1) // 2
    tr = pd.Series(np.nan, index=y.index)
    tr.iloc[k: len(y) - k] = np.convolve(y.to_numpy(), w, mode="valid")
    detr = y - tr if model == "additive" else y / tr
    pos = np.arange(len(y)) % period
    seas = detr.groupby(pos).mean()
    seas = seas - seas.mean() if model == "additive" else seas / seas.mean()
    seas = pd.Series(seas.reindex(pos).to_numpy(), index=y.index)
    resid = y - tr - seas if model == "additive" else y / (tr * seas)
    return tr, seas, resid


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv", nargs="?")
    ap.add_argument("--date"); ap.add_argument("--value")
    ap.add_argument("--category"); ap.add_argument("--keep")
    ap.add_argument("--source", default="(cite your source)")
    ap.add_argument("--downloaded", default="(date downloaded)")
    ap.add_argument("--demo", action="store_true")
    a = ap.parse_args()
    style_defaults()

    if a.demo:
        f = HERE.parent.parent / "week1" / "assignments" / "data" / "flights.csv"
        d = pd.read_csv(f)
        s = pd.Series(d.passengers.to_numpy(),
                      index=pd.to_datetime(d.year.astype(str) + "-" + d.month, format="%Y-%B"))
        src, dl, name = "seaborn flights dataset (Week 1 copy) - DEMO ONLY", "n/a", "air passengers"
    else:
        if not (a.csv and a.date and a.value):
            sys.exit(__doc__)
        d = pd.read_csv(a.csv)
        if a.category and a.keep:
            d = d[d[a.category] == a.keep]
        s = d.assign(_t=pd.to_datetime(d[a.date])).set_index("_t")[a.value].astype(float)
        s = s.groupby(pd.Grouper(freq="MS")).sum(min_count=1)       # flow -> monthly sum
        src, dl, name = a.source, a.downloaded, a.value
    s = s.sort_index().asfreq("MS")
    assert len(s) >= 18, "Part F needs at least 18 months"

    aud = audit_index(s.dropna(), "MS")
    print(f"audit_index: rows={aud['n_rows']} duplicates={aud['n_duplicated']} "
          f"missing={aud['n_missing']} span={aud['span']} partial_tail={aud['partial_tail']}")
    y = s.interpolate()
    figsize = banked_figsize(y.to_numpy(), width=7.5)
    print(f"banked figsize: {figsize[0]:.1f} x {figsize[1]:.1f} in  (aspect {figsize[1] / figsize[0]:.2f})")

    ta, sa, ra = decompose(y, 12, "additive")
    tm, sm, rm = decompose(y, 12, "multiplicative")

    # the number that settles it: does the swing grow in absolute terms only,
    # or also relative to the level?
    yr = y.groupby(y.index.year)
    full = [g for _, g in yr if len(g) == 12]
    amp = np.array([g.max() - g.min() for g in full])
    lvl = np.array([g.mean() for g in full])
    rel = amp / lvl
    cv_abs, cv_rel = amp.std() / amp.mean(), rel.std() / rel.mean()
    sd_add = ra.dropna()
    half = len(sd_add) // 2
    ratio_add = sd_add.iloc[half:].std() / sd_add.iloc[:half].std()
    sd_mul = (rm.dropna() - 1)
    ratio_mul = sd_mul.iloc[half:].std() / sd_mul.iloc[:half].std()
    print(f"swing (max-min) per full year: {amp.round(1).tolist()}")
    print(f"swing / yearly mean          : {rel.round(3).tolist()}  (CV abs {cv_abs:.2f} vs CV relative {cv_rel:.2f})")
    print(f"residual SD, 2nd half / 1st half: additive {ratio_add:.2f}, multiplicative {ratio_mul:.2f}")
    grows = amp[-1] / amp[0]
    lvlg = lvl[-1] / lvl[0]
    mostly_level = cv_rel < cv_abs          # swing tracks the level far better than it tracks a constant
    strengthening = rel[-1] / rel[0]        # >1 means the swing grew faster than the level
    print("ANSWER:")
    print(f"The absolute swing grew {grows:.1f}x ({amp[0]:.0f} to {amp[-1]:.0f}) while the level grew "
          f"{lvlg:.1f}x; as a share of the level it moved from {rel[0] * 100:.0f}% to {rel[-1] * 100:.0f}% "
          f"(CV {cv_rel:.2f} vs {cv_abs:.2f} for the raw swing).")
    if mostly_level and strengthening > 1.15:
        print("So the swing is mostly the level growing (multiplicative seasonality: the multiplicative "
              f"residual is the calmer one), but the seasonal share itself also rose by {(strengthening - 1) * 100:.0f}%, "
              "so a smaller part of the growth is genuinely stronger seasonality.")
    elif mostly_level:
        print("The seasonality is multiplicative: the swing grows because the series grows, not because "
              "the seasonal pattern strengthened.")
    else:
        print("The swing grows faster than the level, so the seasonality itself is strengthening.")

    fig = plt.figure(figsize=(17, 5.2), constrained_layout=True)
    gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1, 1.3])
    ax1 = fig.add_subplot(gs[0])
    ax1.plot(y.index, y.values, color=C[0])
    ax1.set_title(f"{name}: level and swing grow together")
    ax1.set_ylabel(f"{name} (monthly)"); ax1.set_xlabel(f"Month (aspect banked to 45°: {figsize[1] / figsize[0]:.2f})")
    ax1.set_aspect("auto"); ax1.grid(False); ax1.yaxis.grid(True)
    ax2 = fig.add_subplot(gs[1])
    cycle_plot(ax2, y, by="month")
    ax2.set_title(f"Cycle plot: swing is {rel[0] * 100:.0f}% of level in year 1, {rel[-1] * 100:.0f}% in the last")
    ax2.set_ylabel(f"{name} (monthly)"); ax2.legend(title="year", fontsize=7, ncol=2)
    sub = gs[2].subgridspec(1, 2, wspace=0.12)
    axa = fig.add_subplot(sub[0]); axm = fig.add_subplot(sub[1])
    axa.plot(ra.index, ra.values, color=C[1], marker="o", markersize=2.5)
    axa.axhline(0, color=PALETTE["ink_soft"], linewidth=0.8)
    axa.set_title(f"Additive residual\n(SD x{ratio_add:.1f} later)", fontsize=10)
    axm.plot(rm.index, rm.values, color=C[2], marker="o", markersize=2.5)
    axm.axhline(1, color=PALETTE["ink_soft"], linewidth=0.8)
    axm.set_title(f"Multiplicative residual\n(SD x{ratio_mul:.1f} later)", fontsize=10)
    axa.set_ylabel("residual (units)"); axm.set_ylabel("residual (ratio to 1)")
    for ax in (ax1, ax2, axa, axm):
        for sp in ax.spines.values():
            sp.set_visible(False)
    save_fig(fig, HERE / "partF_cycle.png",
             note=f"Source: {src}; downloaded {dl}. Monthly; decomposition period 12; "
                  f"{aud['n_missing']} missing months interpolated for decomposition only.")
    plt.close(fig)
    print("saved partF_cycle.png")


if __name__ == "__main__":
    main()
