"""
clean_sessions.py -- every data rule for sessions_hourly.csv, applied and logged.

    hourly, daily, slog = load_clean_sessions()

hourly : recorded hours only, sorted DatetimeIndex, no duplicates.
         `sessions` is NaN where the collector wrote the -1 sentinel;
         `sessions_filled` has those hours filled (used ONLY for daily sums).
daily  : complete calendar of days (freq "D"), column `sessions` = sum of the
         filled hourly counts. Days that were never recorded stay NaN, so the
         plotted line breaks there instead of dropping to zero.
slog   : dict of every rule applied, with counts.

The six faults, in the order they are handled:
  1. two timestamp formats (ISO, and DD/MM/YYYY HH:MM from the slash logger)
  2. exact duplicate hours (some written once per format)
  3. device label spelled three ways (Mobile / mobile / MOBILE ...)
  4. sentinel -1 in `sessions`
  5. whole days that were never recorded (13)
  6. the extract stops part-way through September 2025
"""
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).parent
DATA = HERE / "data"


def load_clean_sessions(path=None):
    path = Path(path) if path else DATA / "sessions_hourly.csv"
    df = pd.read_csv(path)
    log = {"rows_in": int(len(df))}

    # ---- 1. parse both formats explicitly (never format="mixed") ------------
    iso = df.ts.str.match(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$")
    log["n_iso"] = int(iso.sum())
    log["n_slash"] = int((~iso).sum())
    first = df.ts[~iso].str.extract(r"^(\d+)/")[0].astype(int)
    # a first field above 12 cannot be a month -> the slash logger is day-first
    log["slash_first_field_gt12"] = int((first > 12).sum())
    assert (first > 12).any(), "format would be ambiguous"

    t = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns]")
    t[iso] = pd.to_datetime(df.ts[iso], format="%Y-%m-%d %H:%M:%S")
    t[~iso] = pd.to_datetime(df.ts[~iso], format="%d/%m/%Y %H:%M")
    assert t.notna().all()
    wrong = pd.to_datetime(df.ts[~iso], format="%m/%d/%Y %H:%M", errors="coerce")
    log["span"] = f"{t.min():%Y-%m-%d} to {t.max():%Y-%m-%d}"
    allwrong = pd.concat([t[iso], wrong.dropna()])
    log["span_if_month_first"] = (f"{allwrong.min():%Y-%m-%d} to "
                                  f"{allwrong.max():%Y-%m-%d} "
                                  f"({int(wrong.isna().sum())} rows would be NaT)")
    df["t"] = t

    # ---- 2. exact duplicate hours -------------------------------------------
    dup = df.t.duplicated(keep=False)
    grp = df[dup].groupby("t")[["sessions", "orders", "revenue_pkr"]].nunique()
    log["n_duplicates"] = int(df.t.duplicated().sum())
    log["dup_identical_values"] = bool((grp.max(axis=1) == 1).all())
    fmt = df[dup].assign(is_iso=iso[dup]).groupby("t").is_iso.nunique()
    log["dup_pairs_across_formats"] = int((fmt == 2).sum())
    df = df.drop_duplicates("t", keep="first")

    # ---- 3. device labels ----------------------------------------------------
    log["device_before"] = df.device.value_counts().to_dict()
    df["device"] = df.device.str.strip().str.title()
    log["device_after"] = df.device.value_counts().to_dict()

    df = df.set_index("t").sort_index().drop(columns="ts")
    df.index.name = "ts"
    assert df.index.is_monotonic_increasing and not df.index.duplicated().any()

    # ---- 4. sentinel -1 -------------------------------------------------------
    sent = df.sessions == -1
    log["n_sentinel"] = int(sent.sum())
    df["sessions_was_sentinel"] = sent
    df["sessions"] = df.sessions.where(~sent).astype(float)

    # fill: mean of the two neighbouring hours if both are real; otherwise the
    # median of that weekday-hour across the file.
    grid = df.sessions.reindex(pd.date_range(df.index.min(), df.index.max(),
                                             freq="h"))
    nb = (grid.shift(1) + grid.shift(-1)) / 2          # NaN if either is NaN
    wh = (df.assign(dow=df.index.dayofweek, hr=df.index.hour)
            .groupby(["dow", "hr"]).sessions.median())
    filled = df.sessions.copy()
    n_nb = n_wh = 0
    for ts in df.index[sent]:
        v = nb.get(ts, np.nan)
        if np.isnan(v):
            v = wh.loc[(ts.dayofweek, ts.hour)]
            n_wh += 1
        else:
            n_nb += 1
        filled[ts] = v
    df["sessions_filled"] = filled
    log["n_imputed_by_neighbour_mean"] = n_nb
    log["n_imputed_by_weekday_hour_median"] = n_wh
    log["n_imputed_hours"] = n_nb + n_wh
    log["imputed_share_of_sessions_pct"] = float(
        filled[sent].sum() / filled.sum() * 100)

    # ---- 5. gaps: count on the HOURLY index, before any resample --------------
    full = pd.date_range(df.index.min(), df.index.max(), freq="h")
    missing = full.difference(df.index)
    log["expected_hours"] = int(len(full))
    log["missing_hours"] = int(len(missing))
    mdays = pd.Series(1, index=missing).groupby(missing.normalize()).sum()
    assert (mdays == 24).all(), "a day is partly missing"
    log["missing_days"] = [str(d.date()) for d in mdays.index]
    log["rows_out"] = int(len(df))

    # daily sum of a flow; unrecorded days stay NaN (min_count=1), not 0
    daily = (df.sessions_filled.resample("D").sum(min_count=1)
               .rename("sessions").to_frame())
    assert daily.index.freqstr == "D"
    assert daily.sessions.isna().sum() == len(mdays)

    # ---- 6. partial final month ----------------------------------------------
    last = df.index.max()
    log["partial_month"] = f"{last:%Y-%m}"
    log["partial_days_present"] = int(
        daily.loc[f"{last:%Y-%m}"].sessions.notna().sum())
    log["partial_days_in_month"] = int(last.days_in_month)

    return df, daily, log


if __name__ == "__main__":
    h, d, lg = load_clean_sessions()
    for k, v in lg.items():
        print(f"{k}: {v}")
