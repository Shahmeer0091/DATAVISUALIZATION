# Week 2 — Visualisation and Perception Exercises

## Contents
- `task1.ipynb` — Preattentive attributes and visual search
- `task2.ipynb` — Gestalt principles of grouping
- `task3.ipynb` — Cognitive load and data-ink ratio
- `task4.ipynb` — Channel effectiveness and perceptual accuracy
- `task5.ipynb` — Capstone chart redesign
- `assignments/data/` — CSV datasets used by the notebooks
- `assignments/TASKS.md` — Assignment brief and task instructions
- `perception_redesign.png` — Supporting visual asset
- `channel_results.csv` — Supporting results file

## How to run
1. Extract the ZIP while preserving the `week2` folder.
2. Open the project folder in VS Code or Jupyter.
3. Install the notebook dependencies if needed:
   `pip install pandas numpy matplotlib`
4. Run each notebook from top to bottom.

## Important completion note
Some notebooks contain empty templates for participant/reader observations. These are intentionally not fabricated. Complete those sections using your own observations or collected data, and update written interpretations so they accurately describe your results.

## Submission checklist
- Run all cells from top to bottom.
- Check that plots render and there are no errors.
- Complete all response tables and written reflections required by `assignments/TASKS.md`.
- Remove temporary outputs only if your course instructions permit it.
- Make sure you understand and can explain each chart and conclusion.
