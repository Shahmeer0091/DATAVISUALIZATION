WEEK 1 SOLVED ASSIGNMENTS

Files:
- Task1_Datasaurus.ipynb
- Task2_Gapminder.ipynb
- Task3_Penguins.ipynb
- Task4_MPG.ipynb
- Task5_Flights.ipynb
- data/ (required CSV datasets)

How to run:
1. Extract this ZIP.
2. Open the folder in VS Code or Jupyter.
3. Install if needed: pip install pandas numpy matplotlib seaborn jupyter
4. Open each notebook and run cells from top to bottom.
5. Keep the data folder beside the notebooks.

Note: Charts are generated when you run the notebook cells. Dataset-dependent interpretations are included in Markdown cells.
