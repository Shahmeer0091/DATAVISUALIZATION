# Week 3 — Worked Solution Pack

This pack includes worked notebooks for Parts A–E and the optional bonus.

## Files to use
- `task1.ipynb` — Part A: rebuild the nine charts, calculations, diagnoses, and redesigns.
- `taskb.ipynb` — Part B: Lie Factor audit.
- `taskc.ipynb` — Part C: colour-vision simulation and palette audit.
- `taske.ipynb` — Parts D/E: clinical review figure and written justification.
- `bones.ipynb` — optional preattentive-search bonus and timing template.
- `analysis.md` — written analysis and interpretation of the results.
- `assignments/` — task brief, toolkit, starter files, and required datasets.

## Run it in VS Code
Open the `week3` folder (not the ZIP preview), then install the libraries in the same Python environment used by Jupyter:

```bash
python -m pip install pandas numpy matplotlib seaborn scipy jupyter ipykernel
```

Open each notebook and select that environment as the kernel. Run cells from top to bottom. The notebooks expect the datasets in `assignments/data/`, which is included.

## Suggested order
1. `task1.ipynb`
2. `taskb.ipynb`
3. `taskc.ipynb`
4. `taske.ipynb`
5. `bones.ipynb` (optional)

## Before submitting
- Read each explanation and make sure you can explain the mechanism and numbers in your own words.
- Re-run the notebooks in your own environment and check that figures are generated.
- The bonus timing analysis needs real observations from five classmates; do not invent timings.
- The data is synthetic and created for the course case study. State this when reporting its findings.
- Follow your instructor's required naming and submission format.
